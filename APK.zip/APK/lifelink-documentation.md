# LifeLink - Android Blood Donation App Documentation

## Table of Contents
1. [Project Overview](#project-overview)
2. [Features](#features)
3. [Technical Architecture](#technical-architecture)
4. [Project Structure](#project-structure)
5. [Technologies Used](#technologies-used)
6. [Setup and Installation](#setup-and-installation)
7. [API Integration](#api-integration)
8. [User Interface](#user-interface)
9. [Data Models](#data-models)
10. [Business Logic](#business-logic)
11. [Authentication System](#authentication-system)
12. [Database Schema](#database-schema)
13. [Contributing](#contributing)
14. [Future Enhancements](#future-enhancements)

## Project Overview

LifeLink is a real-time Android application that connects blood donors with people in need of blood donations. The app provides a platform where users can post urgent blood requests to a live feed, and potential donors can instantly accept these requests. The application facilitates secure contact information sharing to streamline the donation process and help save lives.

**Key Purpose**: Bridge the gap between blood donors and recipients through a user-friendly mobile platform that enables quick, efficient, and secure blood donation coordination.

## Features

### Core Features
- **Real-time Blood Request System**: Users can create and post blood donation requests that appear instantly in a live feed
- **Instant Donor Response**: Donors can browse pending requests and instantly accept them with a single tap
- **Secure Contact Sharing**: Automatic sharing of contact information between matched donors and recipients
- **Multi-urgency Support**: Support for emergency requests and scheduled donations
- **Comprehensive Hospital Network**: Integration with local hospitals in the Barasat area
- **User Profile Management**: Complete user profiles with blood group information
- **Request Status Tracking**: Real-time updates on request status (Pending/Accepted)

### User Roles
1. **Blood Recipients**: Can create requests, specify urgency, and receive donor contact information
2. **Blood Donors**: Can browse requests, accept donations, and provide their contact information
3. **Dual Role Users**: Users can both request and donate blood as needed

### Request Types
- **Emergency Requests**: Immediate blood need with highest priority
- **Scheduled Requests**: 
  - Same-day appointments with specific time
  - Future date scheduling with calendar picker

## Technical Architecture

### Architecture Pattern
- **MVVM (Model-View-ViewModel)**: Clean separation of concerns with reactive data binding
- **Repository Pattern**: Centralized data management with abstraction layer
- **Observer Pattern**: Reactive UI updates using StateFlow and coroutines

### Key Architectural Components
1. **Views**: Activities and Fragments for UI
2. **ViewModels**: Business logic and state management
3. **Repositories**: Data access layer
4. **Models**: Data classes and entities
5. **API Client**: Supabase integration layer

## Project Structure

```
app/src/main/java/com/lifelink/lifelink/
├── api/
│   └── SupabaseClient.kt                 # Supabase configuration and client
├── data/
│   ├── BloodRequest.kt                   # Blood request data model
│   ├── User.kt                           # User and Profile data models
│   ├── UserRepository.kt                 # User data operations
│   └── BloodRequestRepository.kt         # Blood request operations
├── ui/
│   ├── auth/
│   │   ├── activity/
│   │   │   └── AuthActivity.kt           # Authentication main activity
│   │   └── fragments/
│   │       ├── SignInFragment.kt         # User login
│   │       ├── RegistrationFragment.kt   # User registration
│   │       └── ForgetPasswordFragment.kt # Password reset
│   └── main/
│       ├── MainActivity.kt               # Main app navigation
│       └── fragments/
│           ├── dashboard/
│           │   └── DashboardFragment.kt  # Home screen with active requests
│           ├── donate/
│           │   └── DonateFragment.kt     # Browse and accept requests
│           ├── requesthelp/
│           │   ├── RequestHelpFragment.kt # Create new blood requests
│           │   └── BloodRequestAdapter.kt # RecyclerView adapter
│           └── profile/
│               └── ProfileFragment.kt     # User profile management
├── viewModels/
│   ├── AuthViewModel.kt                  # Authentication business logic
│   └── MainViewModel.kt                  # Main app business logic
└── MyLifelinkApp.kt                      # Application class
```

## Technologies Used

### Frontend
- **Kotlin**: Primary programming language
- **Android SDK**: Target SDK 36, Minimum SDK 27
- **View Binding & Data Binding**: Type-safe view references
- **Android Architecture Components**: ViewModel, LiveData patterns
- **Material Design**: UI components and theming
- **RecyclerView**: Efficient list displays
- **SwipeRefreshLayout**: Pull-to-refresh functionality

### Backend & Database
- **Supabase**: Backend-as-a-Service platform
- **PostgreSQL**: Database (via Supabase)
- **Supabase Auth**: User authentication and session management
- **Supabase Realtime**: Real-time data synchronization

### Networking & Serialization
- **Ktor Client**: HTTP client for Android
- **Kotlinx Serialization**: JSON serialization/deserialization
- **OkHttp**: HTTP client backend

### Development Tools
- **Gradle KTS**: Build configuration
- **Android Studio**: IDE
- **Git**: Version control

## Setup and Installation

### Prerequisites
- Android Studio Arctic Fox or later
- Android SDK 27+
- Kotlin 1.9.0+
- Supabase account and project

### Installation Steps

1. **Clone the Repository**
   ```bash
   git clone https://github.com/kaityritam/LIfeLink.git
   cd LIfeLink
   ```

2. **Supabase Configuration**
   - Create a new project on [Supabase](https://supabase.com)
   - Get your project URL and anonymous key
   - Create a `local.properties` file in the root directory:
   ```properties
   PROJECT_URL=your_supabase_project_url
   PROJECT_ANON_KEY=your_supabase_anon_key
   ```

3. **Database Setup**
   Create the following tables in your Supabase database:
   
   **Users Table:**
   ```sql
   CREATE TABLE users (
     id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
     name TEXT,
     phone TEXT,
     email TEXT UNIQUE,
     blood_group TEXT,
     is_email_verified BOOLEAN DEFAULT false,
     created_at TIMESTAMP DEFAULT NOW()
   );
   ```
   
   **Blood Requests Table:**
   ```sql
   CREATE TABLE blood_requests (
     id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
     created_at TIMESTAMP DEFAULT NOW(),
     requester_id UUID REFERENCES users(id),
     blood_type TEXT NOT NULL,
     hospital_name TEXT NOT NULL,
     urgency TEXT NOT NULL,
     details TEXT NOT NULL,
     status TEXT DEFAULT 'Pending',
     donor_id UUID REFERENCES users(id)
   );
   ```

4. **Build and Run**
   - Open the project in Android Studio
   - Sync project with Gradle files
   - Run the app on an Android device or emulator

## API Integration

### Supabase Client Configuration
The app uses Supabase as the backend service with the following configuration:

```kotlin
object SupabaseClient {
    lateinit var client: SupabaseClient
    
    fun initialize(context: Context) {
        client = createSupabaseClient(
            supabaseUrl = BuildConfig.PROJECT_URL,
            supabaseKey = BuildConfig.PROJECT_ANON_KEY
        ) {
            install(Postgrest)  // Database operations
            install(Auth) {     // Authentication
                autoLoadFromStorage = true
            }
        }
    }
}
```

### Data Operations
- **User Management**: Registration, login, profile fetching
- **Blood Requests**: CRUD operations with real-time updates
- **Authentication**: Session management and security

## User Interface

### Navigation Structure
The app uses a custom fragment-based navigation system with bottom navigation:

1. **Dashboard**: Home screen showing active requests and donations
2. **Donate**: Browse and accept pending blood requests
3. **Request Help**: Create new blood donation requests
4. **Profile**: User profile and account management

### Key UI Components
- **Bottom Navigation**: Custom implementation with stack management
- **RecyclerView**: Efficient list display for blood requests
- **Custom Adapters**: Specialized adapters for blood request cards
- **Material Design**: Consistent UI following Material Design principles
- **Form Validation**: Real-time form validation for request creation

### Responsive Design
- Edge-to-edge display support
- Dynamic UI updates based on data state
- Loading states with SwipeRefreshLayout
- Error handling with user-friendly messages

## Data Models

### User Model
```kotlin
@Serializable
data class User(
    val id: String? = null,
    val name: String? = null,
    val phone: String? = null,
    val email: String? = null,
    @SerialName("blood_group") val bloodGroup: String? = null,
    @SerialName("is_email_verified") val isEmailVerified: Boolean = false,
    @SerialName("created_at") val createdAt: String? = null
)
```

### Blood Request Model
```kotlin
@Serializable
data class BloodRequest(
    val id: String? = null,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("requester_id") val requesterId: String,
    @SerialName("blood_type") val bloodType: String,
    @SerialName("hospital_name") val hospitalName: String,
    val urgency: String,
    val details: String,
    var status: String = "Pending",
    @SerialName("donor_id") val donorId: String? = null
)
```

## Business Logic

### Authentication Flow
1. **Registration**: Email/password with profile information
2. **Login**: Email/password authentication
3. **Session Management**: Automatic session persistence
4. **Logout**: Clean session termination

### Blood Request Workflow
1. **Request Creation**: User creates blood request with details
2. **Request Display**: Appears in real-time feed for donors
3. **Request Acceptance**: Donors can accept requests
4. **Contact Sharing**: Automatic contact information exchange
5. **Status Updates**: Real-time status tracking

### Data Synchronization
- Real-time updates using Supabase's real-time features
- Automatic UI refresh on data changes
- Offline-first approach with local state management

## Authentication System

### Features
- Email/password authentication
- User registration with profile creation
- Password reset functionality
- Session persistence across app launches
- Secure logout with session cleanup

### Security Measures
- Encrypted password storage (handled by Supabase)
- Session token management
- Secure API communication
- User data validation

## Database Schema

### Tables Overview
1. **users**: User profiles and authentication data
2. **blood_requests**: Blood donation requests and status
3. **profiles**: Extended user profile information

### Relationships
- Users can create multiple blood requests (one-to-many)
- Blood requests link requesters to donors (many-to-one)
- Profile information extends user data

## Contributing

### Development Guidelines
1. Follow Kotlin coding conventions
2. Use MVVM architecture pattern
3. Implement proper error handling
4. Add unit tests for business logic
5. Update documentation for new features

### Pull Request Process
1. Fork the repository
2. Create a feature branch
3. Implement changes with tests
4. Update documentation
5. Submit pull request with description

## Future Enhancements

### Planned Features
- **Push Notifications**: Real-time alerts for new requests
- **Geolocation**: Location-based request filtering
- **Rating System**: User feedback and rating system
- **Medical History**: Integration with medical records
- **Blood Bank Integration**: Direct integration with blood banks
- **Multi-language Support**: Localization for different regions
- **Advanced Analytics**: Usage statistics and insights
- **Emergency Contacts**: Integration with emergency services

### Technical Improvements
- **Offline Support**: Enhanced offline capabilities
- **Performance Optimization**: Improved loading times
- **Security Enhancements**: Additional security measures
- **API Optimization**: Better data caching strategies
- **UI/UX Improvements**: Enhanced user experience

---

*This documentation provides a comprehensive overview of the LifeLink Android application. For specific implementation details, please refer to the source code and inline comments.*